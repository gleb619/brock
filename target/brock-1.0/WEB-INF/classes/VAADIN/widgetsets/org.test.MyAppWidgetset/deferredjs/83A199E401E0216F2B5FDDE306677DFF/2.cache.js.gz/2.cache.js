$wnd.org_test_MyAppWidgetset.runAsyncCallback2('Bbb(1540,1,bTd);_.tc=function Wac(){gZb((!_Yb&&(_Yb=new lZb),_Yb),this.a.d)};FMd(Th)(2);\n//# sourceURL=org.test.MyAppWidgetset-2.js\n')
